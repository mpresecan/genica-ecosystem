import * as React from "react"
import { cn } from "../lib/utils"
import { NETWORK, type LineId } from "../brand"

/**
 * The switcher. Plain text, current one in ink, the rest muted. No status
 * dots, no coloured dashes.
 */
export function NetworkRail({
  current,
  className,
}: {
  current: LineId
  className?: string
}) {
  return (
    <nav aria-label="Genica network" className={cn("border-b border-hair-soft bg-paper", className)}>
      <div className="mx-auto w-full max-w-[1200px] px-6 sm:px-8">
        <ul
          className="flex items-center gap-7 overflow-x-auto py-2.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          style={{
            maskImage: "linear-gradient(to right, black calc(100% - 1.5rem), transparent)",
            WebkitMaskImage: "linear-gradient(to right, black calc(100% - 1.5rem), transparent)",
          }}
        >
          {NETWORK.map((p) => {
            const active = p.id === current
            return (
              <li key={p.id} className="shrink-0">
                <a
                  href={active ? "/" : p.url}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "text-[0.75rem] leading-none transition-colors",
                    active ? "font-medium text-ink" : "text-faint hover:text-body"
                  )}
                >
                  {p.name}
                </a>
              </li>
            )
          })}
        </ul>
      </div>
    </nav>
  )
}
