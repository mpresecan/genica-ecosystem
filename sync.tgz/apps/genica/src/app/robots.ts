import type { MetadataRoute } from "next";
import { PROPERTIES } from "@genica/ui";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: `${PROPERTIES.genica.url}/sitemap.xml`,
  };
}
